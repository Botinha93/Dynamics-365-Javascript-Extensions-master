/// <reference path="../xrm.ts" />   


function funçãoParaExecutar(executionContext : Xrm.Events.EventContext)
{
    var formContext = executionContext.getFormContext();
}
